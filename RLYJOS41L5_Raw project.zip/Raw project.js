// script.js

// ----- Typing Effect for Header -----
document.addEventListener("DOMContentLoaded", () => {
    const typingText = document.querySelector(".typing-text");
    const fullText = typingText.textContent;
    typingText.textContent = "";
    let index = 0;

    function typeWriter() {
        if (index < fullText.length) {
            typingText.textContent += fullText.charAt(index);
            index++;
            setTimeout(typeWriter, 100);
        }
    }
    typeWriter();
});

// ----- Reveal on Scroll -----
const revealElements = document.querySelectorAll('.reveal');
const observerOptions = {
    threshold: 0.2
};

const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('active');
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

revealElements.forEach(el => observer.observe(el));

// ----- Fetch Crypto Data from CoinGecko API -----
const cryptoListContainer = document.getElementById("cryptoList");
const searchInput = document.getElementById("searchInput");
const searchBtn = document.getElementById("searchBtn");

let cryptoData = [];

async function fetchCryptoData() {
    try {
        const response = await fetch('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd');
        cryptoData = await response.json();
        displayCryptoList(cryptoData);
        createCryptoChart(cryptoData.slice(0, 10)); // Use top 10 for chart
    } catch (error) {
        console.error("Error fetching crypto data:", error);
    }
}

function displayCryptoList(data) {
    cryptoListContainer.innerHTML = "";
    data.forEach(crypto => {
        const div = document.createElement("div");
        div.className = "crypto-item";
        div.innerHTML = `<strong>${crypto.name}</strong> - $${crypto.current_price}`;
        cryptoListContainer.appendChild(div);
    });
}

// Search functionality
searchBtn.addEventListener("click", () => {
    const searchTerm = searchInput.value.toLowerCase();
    const filteredData = cryptoData.filter(crypto =>
        crypto.name.toLowerCase().includes(searchTerm)
    );
    displayCryptoList(filteredData);
    createCryptoChart(filteredData.slice(0, 10)); // update chart with filtered data
});

// ----- Create Chart using Chart.js -----
function createCryptoChart(data) {
    // Remove existing canvas if present
    const existingCanvas = document.getElementById("cryptoChart");
    if (existingCanvas) {
        existingCanvas.remove();
    }

    // Create a new canvas element for the chart
    const chartSection = document.querySelector(".chart-section");
    const canvas = document.createElement("canvas");
    canvas.id = "cryptoChart";
    chartSection.appendChild(canvas);

    // Prepare data for chart
    const labels = data.map(crypto => crypto.name);
    const prices = data.map(crypto => crypto.current_price);

    // Create chart
    new Chart(canvas, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Current Price (USD)',
                data: prices,
                backgroundColor: 'rgba(0, 115, 230, 0.7)',
                borderColor: 'rgba(0, 115, 230, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            animation: {
                duration: 1500,
                easing: 'easeOutBounce'
            }
        }
    });
}

// Initialize the dashboard
fetchCryptoData();